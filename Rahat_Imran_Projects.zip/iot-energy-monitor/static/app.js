const REFRESH_MS = 2000;
const deviceSelect = document.getElementById("device-select");

const chart = new Chart(document.getElementById("power-chart"), {
  type: "line",
  data: {
    labels: [],
    datasets: [{
      label: "Power (W)",
      data: [],
      borderColor: "#2563eb",
      pointBackgroundColor: [],
      pointRadius: 3,
      tension: 0.2,
    }],
  },
  options: { animation: false, scales: { y: { title: { display: true, text: "Watts" } } } },
});

async function getJSON(url) {
  const response = await fetch(url);
  return response.json();
}

function deviceQuery() {
  return deviceSelect.value ? `device_id=${encodeURIComponent(deviceSelect.value)}` : "";
}

async function loadDevices() {
  const devices = await getJSON("/api/devices");
  const current = deviceSelect.value;
  deviceSelect.innerHTML = devices.map(d => `<option value="${d}">${d}</option>`).join("");
  if (devices.includes(current)) deviceSelect.value = current;
}

async function loadChart() {
  const readings = await getJSON(`/api/readings?limit=60&${deviceQuery()}`);
  chart.data.labels = readings.map(r => r.created_at.slice(11, 19));
  chart.data.datasets[0].data = readings.map(r => r.power);
  chart.data.datasets[0].pointBackgroundColor = readings.map(r => (r.is_anomaly ? "#dc2626" : "#2563eb"));
  chart.data.datasets[0].pointRadius = readings.map(r => (r.is_anomaly ? 6 : 3));
  chart.update();
}

async function loadStats() {
  const s = await getJSON(`/api/stats?${deviceQuery()}`);
  document.getElementById("stat-total").textContent = s.total;
  document.getElementById("stat-avg").textContent = s.avg_power;
  document.getElementById("stat-max").textContent = s.max_power;
  document.getElementById("stat-anomalies").textContent = s.anomalies;
}

async function loadAnomalies() {
  const rows = await getJSON("/api/anomalies?limit=10");
  document.getElementById("anomaly-body").innerHTML = rows.map(r => `
    <tr>
      <td>${r.created_at.replace("T", " ").slice(0, 19)}</td>
      <td>${r.device_id}</td>
      <td>${r.voltage}</td>
      <td>${r.current}</td>
      <td>${r.power}</td>
    </tr>`).join("");
}

async function refresh() {
  await loadDevices();
  await Promise.all([loadChart(), loadStats(), loadAnomalies()]);
}

deviceSelect.addEventListener("change", refresh);
refresh();
setInterval(refresh, REFRESH_MS);
