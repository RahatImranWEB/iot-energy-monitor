# Smart IoT Energy Monitoring & Analytics System

Collects electrical readings from (simulated) smart meters, stores them in SQL, flags abnormal usage, and shows everything on a live web dashboard.

**Stack:** Python, Flask, SQLite, HTML, CSS, JavaScript (Chart.js)

## Run
```bash
pip install -r requirements.txt
python app.py          # terminal 1 -> http://127.0.0.1:5000
python simulator.py    # terminal 2 -> sends readings
```

## REST API
| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/readings` | Add a reading (`device_id`, `voltage`, `current`) |
| GET | `/api/readings` | List readings (`device_id`, `limit`) |
| GET | `/api/devices` | List devices |
| GET | `/api/stats` | Totals, average and peak power, anomaly count |
| GET | `/api/anomalies` | Recent abnormal readings |

Anomaly rule: a reading is abnormal if its power is more than 3 standard deviations from the mean of the device's last 50 readings.
