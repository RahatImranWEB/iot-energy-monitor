import sqlite3
import statistics
from datetime import datetime, timezone

from flask import Flask, g, jsonify, render_template, request

DB_PATH = "energy.db"
WINDOW = 50          # number of past readings used as the baseline
MIN_SAMPLES = 10     # minimum readings before anomaly detection starts
Z_THRESHOLD = 3.0    # how many standard deviations count as abnormal

app = Flask(__name__)


# ---------- Database ----------
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    with sqlite3.connect(DB_PATH) as db:
        db.execute(
            """
            CREATE TABLE IF NOT EXISTS readings (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                device_id  TEXT    NOT NULL,
                voltage    REAL    NOT NULL,
                current    REAL    NOT NULL,
                power      REAL    NOT NULL,
                is_anomaly INTEGER NOT NULL DEFAULT 0,
                created_at TEXT    NOT NULL
            )
            """
        )


# ---------- Analytics ----------
def is_anomalous(db, device_id, power):
    """Flag a reading if it is far from the recent average of the same device."""
    rows = db.execute(
        "SELECT power FROM readings WHERE device_id = ? ORDER BY id DESC LIMIT ?",
        (device_id, WINDOW),
    ).fetchall()
    history = [r["power"] for r in rows]
    if len(history) < MIN_SAMPLES:
        return False
    mean = statistics.mean(history)
    std = statistics.stdev(history)
    if std == 0:
        return False
    return abs(power - mean) / std > Z_THRESHOLD


# ---------- Routes ----------
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/readings", methods=["POST"])
def add_reading():
    data = request.get_json(silent=True) or {}
    try:
        device_id = str(data["device_id"])
        voltage = float(data["voltage"])
        current = float(data["current"])
    except (KeyError, TypeError, ValueError):
        return jsonify(error="device_id, voltage and current are required"), 400

    power = round(voltage * current, 2)  # watts
    db = get_db()
    anomaly = is_anomalous(db, device_id, power)
    created_at = datetime.now(timezone.utc).isoformat(timespec="seconds")

    cur = db.execute(
        "INSERT INTO readings (device_id, voltage, current, power, is_anomaly, created_at) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (device_id, voltage, current, power, int(anomaly), created_at),
    )
    db.commit()
    return jsonify(id=cur.lastrowid, power=power, is_anomaly=anomaly), 201


@app.route("/api/readings", methods=["GET"])
def list_readings():
    device_id = request.args.get("device_id")
    limit = request.args.get("limit", default=100, type=int)
    db = get_db()

    query = "SELECT * FROM readings"
    params = []
    if device_id:
        query += " WHERE device_id = ?"
        params.append(device_id)
    query += " ORDER BY id DESC LIMIT ?"
    params.append(limit)

    rows = db.execute(query, params).fetchall()
    return jsonify([dict(r) for r in reversed(rows)])


@app.route("/api/devices", methods=["GET"])
def list_devices():
    rows = get_db().execute("SELECT DISTINCT device_id FROM readings ORDER BY device_id").fetchall()
    return jsonify([r["device_id"] for r in rows])


@app.route("/api/stats", methods=["GET"])
def stats():
    device_id = request.args.get("device_id")
    where, params = ("WHERE device_id = ?", [device_id]) if device_id else ("", [])
    row = get_db().execute(
        f"""
        SELECT COUNT(*)        AS total,
               AVG(power)      AS avg_power,
               MAX(power)      AS max_power,
               SUM(is_anomaly) AS anomalies
        FROM readings {where}
        """,
        params,
    ).fetchone()
    return jsonify(
        total=row["total"],
        avg_power=round(row["avg_power"] or 0, 2),
        max_power=round(row["max_power"] or 0, 2),
        anomalies=row["anomalies"] or 0,
    )


@app.route("/api/anomalies", methods=["GET"])
def list_anomalies():
    limit = request.args.get("limit", default=10, type=int)
    rows = get_db().execute(
        "SELECT * FROM readings WHERE is_anomaly = 1 ORDER BY id DESC LIMIT ?", (limit,)
    ).fetchall()
    return jsonify([dict(r) for r in rows])


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
