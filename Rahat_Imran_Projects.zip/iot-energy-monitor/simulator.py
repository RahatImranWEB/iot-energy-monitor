import random
import time

import requests

API_URL = "http://127.0.0.1:5000/api/readings"
DEVICES = ["meter-1", "meter-2"]
INTERVAL_SECONDS = 1


def make_reading(device_id):
    voltage = random.gauss(230, 2)
    current = random.gauss(5, 0.4)
    if random.random() < 0.05:           # occasional power surge
        current *= random.uniform(2, 3)
    return {
        "device_id": device_id,
        "voltage": round(voltage, 2),
        "current": round(current, 2),
    }


if __name__ == "__main__":
    print("Sending readings. Press Ctrl+C to stop.")
    while True:
        for device in DEVICES:
            reading = make_reading(device)
            response = requests.post(API_URL, json=reading, timeout=5)
            print(device, reading, response.json())
        time.sleep(INTERVAL_SECONDS)
