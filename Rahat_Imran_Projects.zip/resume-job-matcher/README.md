# Intelligent Resume Screening & Job Matching System

Extracts skills from resumes (PDF or text), compares them with job descriptions, and ranks candidates with a compatibility score and a skill-gap report.

**Stack:** Python, Flask, SQLite, scikit-learn, HTML, CSS, JavaScript

## Run
```bash
pip install -r requirements.txt
python app.py     # http://127.0.0.1:5000
```

## How the score works
`score = 70% skill match + 30% text similarity`
- **Skill match:** share of the job's required skills found in the resume.
- **Text similarity:** TF-IDF cosine similarity between resume and job description.
- **Skill gap:** required skills missing from the resume.

## REST API
| Method | Endpoint | Purpose |
|---|---|---|
| GET / POST | `/api/resumes` | List / upload resumes |
| DELETE | `/api/resumes/<id>` | Delete a resume |
| GET / POST | `/api/jobs` | List / add jobs |
| DELETE | `/api/jobs/<id>` | Delete a job |
| POST | `/api/jobs/<id>/rank` | Score and rank all resumes for a job |
| GET | `/api/jobs/<id>/results` | Saved ranking for a job |

Edit `skills.py` to add or remove skills.
