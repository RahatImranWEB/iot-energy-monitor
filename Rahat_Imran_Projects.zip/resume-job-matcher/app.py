import json
import sqlite3
from datetime import datetime, timezone

from flask import Flask, g, jsonify, render_template, request
from pypdf import PdfReader

from matcher import match
from skills import extract_skills

DB_PATH = "matcher.db"

app = Flask(__name__)


# ---------- Database ----------
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    with sqlite3.connect(DB_PATH) as db:
        db.executescript(
            """
            CREATE TABLE IF NOT EXISTS resumes (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                name       TEXT NOT NULL,
                text       TEXT NOT NULL,
                skills     TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS jobs (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                title       TEXT NOT NULL,
                description TEXT NOT NULL,
                skills      TEXT NOT NULL,
                created_at  TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS results (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                resume_id   INTEGER NOT NULL REFERENCES resumes(id) ON DELETE CASCADE,
                job_id      INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
                score       REAL NOT NULL,
                skill_score REAL NOT NULL,
                text_score  REAL NOT NULL,
                matched     TEXT NOT NULL,
                missing     TEXT NOT NULL
            );
            """
        )


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# ---------- Helpers ----------
def read_upload(file):
    """Extract text from an uploaded PDF or plain-text file."""
    if file.filename.lower().endswith(".pdf"):
        reader = PdfReader(file)
        return "\n".join(page.extract_text() or "" for page in reader.pages)
    return file.read().decode("utf-8", errors="ignore")


# ---------- Routes ----------
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/resumes", methods=["GET"])
def list_resumes():
    rows = get_db().execute("SELECT id, name, skills, created_at FROM resumes ORDER BY id DESC").fetchall()
    return jsonify([{**dict(r), "skills": json.loads(r["skills"])} for r in rows])


@app.route("/api/resumes", methods=["POST"])
def add_resume():
    name = request.form.get("name", "").strip()
    text = request.form.get("text", "").strip()
    file = request.files.get("file")
    if file and file.filename:
        text = read_upload(file).strip()

    if not name or not text:
        return jsonify(error="A name and resume text (or file) are required"), 400

    skills = extract_skills(text)
    db = get_db()
    cur = db.execute(
        "INSERT INTO resumes (name, text, skills, created_at) VALUES (?, ?, ?, ?)",
        (name, text, json.dumps(skills), now()),
    )
    db.commit()
    return jsonify(id=cur.lastrowid, name=name, skills=skills), 201


@app.route("/api/resumes/<int:resume_id>", methods=["DELETE"])
def delete_resume(resume_id):
    db = get_db()
    db.execute("DELETE FROM resumes WHERE id = ?", (resume_id,))
    db.commit()
    return "", 204


@app.route("/api/jobs", methods=["GET"])
def list_jobs():
    rows = get_db().execute("SELECT id, title, skills, created_at FROM jobs ORDER BY id DESC").fetchall()
    return jsonify([{**dict(r), "skills": json.loads(r["skills"])} for r in rows])


@app.route("/api/jobs", methods=["POST"])
def add_job():
    data = request.get_json(silent=True) or {}
    title = str(data.get("title", "")).strip()
    description = str(data.get("description", "")).strip()
    if not title or not description:
        return jsonify(error="title and description are required"), 400

    skills = extract_skills(description)
    db = get_db()
    cur = db.execute(
        "INSERT INTO jobs (title, description, skills, created_at) VALUES (?, ?, ?, ?)",
        (title, description, json.dumps(skills), now()),
    )
    db.commit()
    return jsonify(id=cur.lastrowid, title=title, skills=skills), 201


@app.route("/api/jobs/<int:job_id>", methods=["DELETE"])
def delete_job(job_id):
    db = get_db()
    db.execute("DELETE FROM jobs WHERE id = ?", (job_id,))
    db.commit()
    return "", 204


@app.route("/api/jobs/<int:job_id>/rank", methods=["POST"])
def rank_candidates(job_id):
    """Score every stored resume against one job and return them best-first."""
    db = get_db()
    job = db.execute("SELECT * FROM jobs WHERE id = ?", (job_id,)).fetchone()
    if job is None:
        return jsonify(error="Job not found"), 404

    job_skills = json.loads(job["skills"])
    db.execute("DELETE FROM results WHERE job_id = ?", (job_id,))

    for resume in db.execute("SELECT * FROM resumes").fetchall():
        result = match(resume["text"], json.loads(resume["skills"]), job["description"], job_skills)
        db.execute(
            "INSERT INTO results (resume_id, job_id, score, skill_score, text_score, matched, missing) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                resume["id"], job_id, result["score"], result["skill_score"], result["text_score"],
                json.dumps(result["matched"]), json.dumps(result["missing"]),
            ),
        )
    db.commit()
    return get_results(job_id)


@app.route("/api/jobs/<int:job_id>/results", methods=["GET"])
def get_results(job_id):
    rows = get_db().execute(
        """
        SELECT r.name, res.score, res.skill_score, res.text_score, res.matched, res.missing
        FROM results res JOIN resumes r ON r.id = res.resume_id
        WHERE res.job_id = ?
        ORDER BY res.score DESC
        """,
        (job_id,),
    ).fetchall()
    return jsonify([
        {**dict(r), "matched": json.loads(r["matched"]), "missing": json.loads(r["missing"])}
        for r in rows
    ])


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
