from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

SKILL_WEIGHT = 0.7
TEXT_WEIGHT = 0.3


def text_similarity(resume_text, job_text):
    """Cosine similarity of TF-IDF vectors, between 0 and 1."""
    vectors = TfidfVectorizer(stop_words="english").fit_transform([resume_text, job_text])
    return float(cosine_similarity(vectors[0], vectors[1])[0][0])


def match(resume_text, resume_skills, job_text, job_skills):
    """Compare one resume with one job and return the score and skill gap."""
    matched = [s for s in job_skills if s in resume_skills]
    missing = [s for s in job_skills if s not in resume_skills]

    skill_score = len(matched) / len(job_skills) if job_skills else 0.0
    text_score = text_similarity(resume_text, job_text)
    final_score = SKILL_WEIGHT * skill_score + TEXT_WEIGHT * text_score

    return {
        "score": round(final_score * 100, 1),
        "skill_score": round(skill_score * 100, 1),
        "text_score": round(text_score * 100, 1),
        "matched": matched,
        "missing": missing,
    }
