const resumeForm = document.getElementById("resume-form");
const jobForm = document.getElementById("job-form");
const jobSelect = document.getElementById("job-select");

async function getJSON(url, options) {
  const response = await fetch(url, options);
  const data = response.status === 204 ? null : await response.json();
  if (!response.ok) throw new Error(data?.error || "Request failed");
  return data;
}

function chips(items, cssClass) {
  return items.length
    ? items.map(s => `<span class="chip ${cssClass}">${s}</span>`).join("")
    : '<span class="muted">none</span>';
}

async function loadResumes() {
  const resumes = await getJSON("/api/resumes");
  document.getElementById("resume-list").innerHTML = resumes.map(r => `
    <li>
      <span>${r.name} <small class="muted">(${r.skills.length} skills found)</small></span>
      <button onclick="deleteResume(${r.id})">Delete</button>
    </li>`).join("");
}

async function loadJobs() {
  const jobs = await getJSON("/api/jobs");
  jobSelect.innerHTML = jobs.map(j => `<option value="${j.id}" data-skills="${j.skills.join(", ")}">${j.title}</option>`).join("");
  showJobSkills();
}

function showJobSkills() {
  const option = jobSelect.selectedOptions[0];
  document.getElementById("job-skills").textContent =
    option ? `Required skills detected: ${option.dataset.skills || "none"}` : "No jobs yet.";
}

function showResults(results) {
  document.getElementById("results-body").innerHTML = results.map((r, i) => `
    <tr>
      <td>${i + 1}</td>
      <td>${r.name}</td>
      <td class="score">${r.score}%<br><small class="muted">skills ${r.skill_score}% · text ${r.text_score}%</small></td>
      <td>${chips(r.matched, "ok")}</td>
      <td>${chips(r.missing, "gap")}</td>
    </tr>`).join("");
}

async function deleteResume(id) {
  await getJSON(`/api/resumes/${id}`, { method: "DELETE" });
  loadResumes();
}

resumeForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    await getJSON("/api/resumes", { method: "POST", body: new FormData(resumeForm) });
    resumeForm.reset();
    loadResumes();
  } catch (error) {
    alert(error.message);
  }
});

jobForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const body = JSON.stringify(Object.fromEntries(new FormData(jobForm)));
  try {
    await getJSON("/api/jobs", { method: "POST", headers: { "Content-Type": "application/json" }, body });
    jobForm.reset();
    loadJobs();
  } catch (error) {
    alert(error.message);
  }
});

document.getElementById("rank-btn").addEventListener("click", async () => {
  if (!jobSelect.value) return alert("Add a job first.");
  showResults(await getJSON(`/api/jobs/${jobSelect.value}/rank`, { method: "POST" }));
});

jobSelect.addEventListener("change", showJobSkills);

loadResumes();
loadJobs();
