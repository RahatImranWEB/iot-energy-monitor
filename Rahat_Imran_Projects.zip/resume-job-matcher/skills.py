import re

SKILLS = [
    # Languages
    "python", "java", "c", "c++", "c#", "javascript", "typescript", "sql", "r", "matlab", "go", "kotlin", "php",
    # Web
    "html", "css", "react", "angular", "node.js", "flask", "django", "spring boot", "rest api", "bootstrap",
    # Data and ML
    "pandas", "numpy", "scikit-learn", "tensorflow", "pytorch", "machine learning", "deep learning",
    "data analysis", "data visualization", "power bi", "tableau", "excel", "statistics", "nlp",
    # Databases
    "mysql", "postgresql", "mongodb", "sqlite", "oracle",
    # Tools and cloud
    "git", "github", "docker", "kubernetes", "linux", "aws", "azure", "gcp", "jenkins", "ci/cd",
    # Core CS and engineering
    "data structures", "algorithms", "object-oriented programming", "operating systems", "computer networks",
    "dbms", "embedded systems", "microcontrollers", "digital signal processing", "iot", "arduino",
    # Practices
    "agile", "scrum", "unit testing",
]


def extract_skills(text):
    """Return the skills from SKILLS that appear as whole words in the text."""
    text = text.lower()
    found = []
    for skill in SKILLS:
        pattern = r"(?<![\w+#])" + re.escape(skill) + r"(?![\w+#])"
        if re.search(pattern, text):
            found.append(skill)
    return found
